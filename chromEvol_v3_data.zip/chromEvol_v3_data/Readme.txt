1. ChromEvol_v3_data/non_homogeneous_analyses contains the following folders/files:
	1.1. dependency_func_selection_baseline_model:
		1.1.1. param_files_28_models: Contains the parameter files that were used to find the best dependency functions for each transition type (table 1).
		1.1.2. best_2_candidates: Contains the parameter files that are used to find the best combination of dependency functions for the baseline model among the two candidate suggested models, as described in the manuscript.
	1.2. heterogeneous_model:
		1.2.1. paramFile_heterogeneous_model: The parameter file that was used to assess the non-homogeneous model in the Solanaceae phylogeny (Figures 2 and 3 are based on this analysis).
		1.2.2. parametric_bootstrapping: Contains the parameter file that was used to simulate the chromsome counts data for the bootstrapping analysis, which indicated which rate regimes were significant.
	1.3. chrom_counts.fasta: Chromosome counts data of the Solanaceae phylogeny (741 taxa).
	1.4. pruned_ott_tree_no_white_sp.nwk: The Solanaceae phylogeny (741 taxa).
2. ChromEvol_v3_data/trait_model_analyses contains the following folders/files:
	2.1. chrom_counts.fasta: Chromosome counts that correspond to the pruned Solanaceae phylogeny (297 taxa).
	2.2. pruned_ott_tree_no_white_sp.nwk: The Solanaceae phylogeny (297 taxa).
	2.3. counts_traits_solanaceae.fasta: The SI/SC trait data coded as 0/1, respectively.
	2.4. emprical_data: Contains the trait-independent and the joint model of chromosome numbers and trait model analyses:
		2.4.1: dependency_func_selection_baseline_model: Contains the analyses that were required to determine the baseline model for downstream analyses (similar to 1.1.):
			2.4.1.1. param_files_28_models: Contains the parameter files that were used to find the best dependency functions for each transition type (table 2).
			2.4.1.2. best_2_candidates: Contains the parameter files that are used to find the best combination of dependency functions for the baseline model among the two candidate suggested models, as described in the manuscript.
		2.4.2. fit_trait_models: 
			2.4.2.1. par_independent_no_SC_to_SI_transition: The parameter file that was used to run the trait-independent model, where the trait model assumed no backward transitions from SC to SI.
			2.4.2.2. par_joint_no_SC_to_SI_transition: The parameter file that was used to assess the joint model of chromsome numbers and trait evolution, where the trait model assumed no backward transitions from SC to SI.
			2.4.2.3. par_independent_both_transitions: The parameter file that was used to run the trait-independent model, where the trait model allowed both transitions - from SI to SC and from SC to SI.
			2.4.2.4. par_joint_both_transitions: The parameter file that was used to assess the joint model of chromsome numbers and trait evolution, where the trait model allowed both transitions - from SI to SC and from SC to SI.
	2.5. parametric_bootstrapping:
		2.5.1. sim_params_non_reversible: The parameter file was used to create the simulations that were used for the parametric bootstrapping analyses to assess the significance of the joint model. The trait model used here did not allow transitions from SC to SI.
		2.5.2. sim_params_both_transitions_allowed: The parameter file was used to create the simulations that were used for the parametric bootstrapping analyses to assess the significance of the joint model. The trait model used here allowed both SI->SC and SC->SI.
		2.5.3. test_trait_simulations.py: The script that was used to filter unsuccessful simulations with excessive number of state 1. For details see notes.txt.
	
		