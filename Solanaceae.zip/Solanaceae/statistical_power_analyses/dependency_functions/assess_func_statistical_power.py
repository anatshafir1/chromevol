import numpy
import pandas as pd
import os
import re
import argparse
from typing import List, Tuple, Dict
import math
from ParameterFile import Function


def get_best_function(transition_type: str, res_file_path: str) -> str:
    file = open(res_file_path, 'r')
    content = file.read()
    file.close()
    if transition_type != "baseNum":
        pattern = re.compile(f'{transition_type}:[\s]+([\S]+)')
    else:
        pattern = re.compile(f'{transition_type}R:[\s]+([\S]+)')
    func = pattern.findall(content)[0]
    return func


def get_aicc(res_path: str) -> float:
    pattern = re.compile("AICc[\s]+of[\s]+the[\s]+best[\s]+model[\s]+=[\s]+([\S]+)")
    file = open(res_path, 'r')
    content = file.read()
    file.close()
    aicc = pattern.findall(content)[0]
    return float(aicc)


def get_number_of_true_transitions(evo_path: str, base_number: int) -> Dict[str, float]:
    transition_types_events = {"GAIN":0, "LOSS":0, "DUPLICATION":0, "DEMI-DUPLICATION":0, "BASE-NUMBER":0}
    pattern = re.compile("from state:[\s]+([\d]+)[\s]+t[\s]+=[\s]+[\S]+[\s]+to state[\s]+=[\s]+([\d]+)")
    file = open(evo_path, 'r')
    content = file.read()
    file.close()
    from_to_states = pattern.findall(content)
    for from_state_str, to_state_str in from_to_states:
        from_state = int(from_state_str)
        to_state = int(to_state_str)
        if from_state + 1 == to_state:
            transition_types_events["GAIN"] += 1
        elif from_state - 1 == to_state:
            transition_types_events["LOSS"] += 1
        elif from_state * 2 == to_state:
            transition_types_events["DUPLICATION"] += 1
        elif from_state % 2 == 0 and to_state == 1.5 * from_state:
            transition_types_events["DEMI-DUPLICATION"] += 1
        elif (from_state % 2 != 0) and ((to_state == math.ceil(from_state * 1.5)) or (to_state == math.floor(from_state * 1.5))):
            transition_types_events["DEMI-DUPLICATION"] += 1
        else:
            if base_number > 0:
                if (to_state - from_state) % base_number == 0:
                    transition_types_events["BASE-NUMBER"] += 1
    return transition_types_events


def get_expected_number_of_transitions(expectations_file_path: str) -> Dict[str, float]:
    file = open(expectations_file_path, 'r')
    content = file.read()
    file.close()
    pattern = re.compile('#TOTAL EXPECTATIONS:([^#]+)')
    pattern_transition_type = re.compile("([\S]+):[\s]+([\S]+)")
    expectations = pattern.findall(content)[0]
    transitions_with_expectations = pattern_transition_type.findall(expectations)
    dict_transitions_with_exp = {}
    for transition_type, expectation in transitions_with_expectations:
        dict_transitions_with_exp[transition_type] = float(expectation)
    return dict_transitions_with_exp


def get_average_num_of_transitions(simulations_dir: str, num_of_simulations: int, base_number: int) -> None:
    dict_average_transitions = {"GAIN":0, "LOSS":0, "DUPLICATION":0, "DEMI-DUPLICATION":0, "BASE-NUMBER":0}
    for i in range(num_of_simulations):
        sim_dir = os.path.join(simulations_dir, f'{i}')
        evol_path = os.path.join(sim_dir, 'simulatedEvolutionPaths.txt')
        dict_transitions = get_number_of_true_transitions(evol_path, base_number)
        for transition_type in dict_average_transitions:
            dict_average_transitions[transition_type] += dict_transitions[transition_type]
    for transition_type in dict_average_transitions:
        dict_average_transitions[transition_type] /= num_of_simulations
    print(dict_average_transitions)


def fill_df_dict(sim: int, true_transitions: Dict[str, float], expected_number_of_transitions: Dict[str, float],
                 transition_type: str, func: str, dict_df, best_func: str, true_func: str, bias: int) -> None:
    params_dict = {"gain": "GAIN", "loss": "LOSS", "dupl": "DUPLICATION",
                   "demi": "DEMI-DUPLICATION", "baseNum": "BASE-NUMBER"}
    expected_number_transitions_per_type = expected_number_of_transitions[params_dict[transition_type]]
    dict_df["sim"].append(sim)
    dict_df["transition_type"].append(transition_type)
    dict_df["function"].append(func)
    if bias:
        dict_df["delta"].append(
            expected_number_transitions_per_type - true_transitions[params_dict[transition_type]])
    else:

        dict_df["delta"].append(
            math.fabs(expected_number_transitions_per_type - true_transitions[params_dict[transition_type]]))
    if transition_type == "baseNum" and func == "IGNORE":
        print(f"simulation is: {sim}")
        print(f"Expected: {expected_number_transitions_per_type}")
        print(f"True: {true_transitions[params_dict[transition_type]]}")
        print("*** **** ****\n")
    dict_df["best_model"].append(best_func)
    dict_df["true_func"].append(true_func)

    return


def create_summary_table(df: pd.DataFrame, params: List[str], df_output_file: str) -> None:
    dict_summary = {"transition_type": [], "best_model":[], "correctly_selected_func":[]}
    for func in Function:
        dict_summary[func.value] = []
    for transition_type in params:
        df_transition_type = df[df["transition_type"] == transition_type]
        dict_summary["transition_type"].append(transition_type)
        for func in Function:
            func_name = func.value
            df_func = df_transition_type[df_transition_type["function"] == func_name]
            print(len(df_func), transition_type)
            if len(df_func) > 0:
                mean_delta = df_func["delta"].mean()
                print(mean_delta)
                dict_summary[func_name].append(mean_delta)
            else:
                mean_delta = 0
                print(mean_delta)
                dict_summary[func_name].append(mean_delta)
        df_best_model = df_transition_type[df_transition_type["best_model"] == "yes"]
        mean_delta_best = df_best_model["delta"].mean()
        dict_summary["best_model"].append(mean_delta_best)
        df_true_func = df_best_model[df_best_model["function"] == df_best_model["true_func"]]
        dict_summary["correctly_selected_func"].append(df_true_func["delta"].mean())
    print(dict_summary)
    df_summary = pd.DataFrame(dict_summary)
    df_summary.to_csv(df_output_file)


def get_delta_num_of_transitions(simulations_dir: str, base_number: int, num_of_simulations: int,
                                 output_file_raw: str, output_file_summary: str, func_true_model: str, bias: int) -> None:
    params = ["gain", "loss", "demi", "dupl", "baseNum"]
    dict_df = {"sim": [], "transition_type": [], "delta": [], "function": [], "best_model":[], "true_func":[]}
    dict_true_func = get_function_from_name(func_true_model)
    for i in range(num_of_simulations):
        sim_dir = os.path.join(simulations_dir, f'{i}')
        evol_path = os.path.join(sim_dir, 'simulatedEvolutionPaths.txt')
        dict_of_true_transitions = get_number_of_true_transitions(evol_path, base_number)
        for param in params:
            for func in Function:
                func_name = func.value
                if func_name == "CONST":
                    continue
                elif func_name == "IGNORE" and (param != "demi" and param != "baseNum"):
                    continue
                expectation_file = os.path.join(sim_dir, param, func_name, "expectations_second_round.txt")
                dict_expected_number = get_expected_number_of_transitions(expectation_file)
                fill_df_dict(i, dict_of_true_transitions, dict_expected_number, param, func_name, dict_df, "no", dict_true_func[param], bias)
            expectation_file = os.path.join(sim_dir, "CONST", "expectations_second_round.txt")
            dict_expected_number = get_expected_number_of_transitions(expectation_file)
            fill_df_dict(i, dict_of_true_transitions, dict_expected_number, param, "CONST", dict_df, "no", dict_true_func[param], bias)
            if os.path.exists(os.path.join(sim_dir, "best_complex", "simple_complex_are_same.txt")):
                chrom_res_path = os.path.join(sim_dir, "best_simple", "chromEvol.res")
                expectation_file = os.path.join(sim_dir, "best_simple", "expectations_second_round.txt")
            else:
                chrom_res_path = os.path.join(sim_dir, "best_complex", "chromEvol.res")
                expectation_file = os.path.join(sim_dir, "best_complex", "expectations_second_round.txt")
            best_func = get_best_function(param, chrom_res_path)
            dict_expected_number = get_expected_number_of_transitions(expectation_file)
            fill_df_dict(i, dict_of_true_transitions, dict_expected_number, param, best_func, dict_df, "yes", dict_true_func[param], bias)
    df = pd.DataFrame(dict_df)
    df.to_csv(output_file_raw)
    create_summary_table(df, params, output_file_summary)


def create_table_of_best_chosen(simulations_dir: str, output_file: str, num_of_simulations: int,
                                which_model: int) -> None:
    dict_stats = {}
    params = ["gain", "loss", "dupl", "demi", "baseNum"]
    for i in range(num_of_simulations):
        sim_dir = os.path.join(simulations_dir, f'{i}')
        if which_model == 1:
            res_path = os.path.join(sim_dir, "best_complex", "chromEvol.res")
            if (not os.path.exists(res_path)) and (os.path.exists(os.path.join(sim_dir, "best_complex", "simple_complex_are_same.txt"))):
                res_path = os.path.join(sim_dir, "best_simple", "chromEvol.res")
        elif which_model == 0:
            res_path = os.path.join(sim_dir, "best_simple", "chromEvol.res")
        else:
            if os.path.exists(os.path.join(sim_dir, "best_complex", "simple_complex_are_same.txt")):
                res_path = os.path.join(sim_dir, "best_simple", "chromEvol.res")
            else:
                res1 = os.path.join(sim_dir, "best_simple", "chromEvol.res")
                res2 = os.path.join(sim_dir, "best_complex", "chromEvol.res")
                aicc1 = get_aicc(res1)
                aicc2 = get_aicc(res2)
                if aicc1 <= aicc2:
                    res_path = os.path.join(sim_dir, "best_simple", "chromEvol.res")
                elif aicc1-aicc2 < 2:
                    res_path = os.path.join(sim_dir, "best_simple", "chromEvol.res")
                else:
                    res_path = os.path.join(sim_dir, "best_complex", "chromEvol.res")

        for param in params:
            func = get_best_function(param, res_path)
            if not param in dict_stats:
                dict_stats[param] = {func: 1}
            else:
                if not func in dict_stats[param]:
                    dict_stats[param][func] = 1
                else:
                    dict_stats[param][func] += 1
    print(dict_stats)
    dict_df = {"IGNORE":[],"CONST":[], "LINEAR_BD":[], "LINEAR":[], "EXP":[], "LOGNORMAL":[], "REVERSE_SIGMOID":[]}
    for func in dict_df:
        for param in params:
            if not func in dict_stats[param]:
                dict_df[func].append(0)
            else:
                dict_df[func].append(dict_stats[param][func] / num_of_simulations)

    df = pd.DataFrame(dict_df)
    df.index = params
    df.to_csv(output_file)


def get_function_from_name(combined_func: str) -> Dict[str, str]:
    dict_transition_types = {"g": "gain", "l": "loss", "du": "dupl", "de": "demi", "b": "baseNum"}
    transition_type_vs_func = combined_func.split("+")
    dict_functions = {}
    for item in transition_type_vs_func:
        transition_type_abbr, func = item.split("_", 1)
        dict_functions[dict_transition_types[transition_type_abbr]] = func
    return dict_functions




if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="run homogeneous analyses")
    parser.add_argument("--simulation_dir", "-s", help="simulation directory")
    parser.add_argument("--output_file", "-o", help="out_file", default=None)
    parser.add_argument("--num_of_sim", "-n", type=int, help="number of simulations")
    parser.add_argument("--which_model", "-m", type=int, help="which model to consider")
    parser.add_argument("--accuracy_assessment", "-a", type=int, help="1 if accuracy anaysis is on")
    parser.add_argument("--base_number", "-b", type=int, help="base number", default=None)
    parser.add_argument("--out_full_table", "-of", help="path for the full accuracy table", default=None)
    parser.add_argument("--out_for_summary_table", "-os", help="path for the summary accuracy table", default=None)
    parser.add_argument("--true_func_model", "-f", help = "function model")
    parser.add_argument("--bias", "-bias", type=int, help="bias", default=0)

    args = parser.parse_args()
    simulation_dir = args.simulation_dir
    num_of_sim = args.num_of_sim
    output_file = args.output_file
    which_model = args.which_model
    accuracy_assessment = args.accuracy_assessment
    base_number = args.base_number
    output_file_raw = args.out_full_table
    output_file_summary = args.out_for_summary_table
    function_model = args.true_func_model
    bias = args.bias
    if accuracy_assessment:
        get_delta_num_of_transitions(simulation_dir, base_number, num_of_sim, output_file_raw, output_file_summary,
                                     function_model, bias)
    else:
        create_table_of_best_chosen(simulation_dir, output_file, num_of_sim,
                                which_model)

