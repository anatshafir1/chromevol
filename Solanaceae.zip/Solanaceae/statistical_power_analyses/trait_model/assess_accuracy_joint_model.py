import os
import re
import numpy as np
from typing import Tuple, List, Dict
from simulateChromosomeData import get_max_chromosome_number, get_min_chromosome_number, get_tree_scaling_factor
import pandas as pd
import argparse
import math
# comparison f1(i)-f2(i)
# average between delta = f1(i)-f2(i)


def Const(params: List[float], x: np.ndarray) -> np.ndarray:
    return np.array([params[0] for i in range(len(x))])


def Linear_BD(params: List[float], x: np.ndarray) -> np.ndarray:
    return x * params[0]


def Linear(params: List[float], x: np.ndarray) -> np.ndarray:
    return params[0] + params[1]*(x-1)


def Exp(params: List[float], x: np.ndarray) -> np.ndarray:
    return params[0] * np.exp(params[1]*(x-1))


def Rev_Sigmoid(params: List[float], x: np.ndarray) -> np.ndarray:
    return params[0]/(1+np.exp(params[1]-(params[2]*x)))


def Log_normal(params: List[float], x: np.ndarray) -> np.ndarray:
    range_factor = params[0]
    scaling_factor = max(x)/4
    transformed = x / scaling_factor
    mu = params[1]
    sigma = params[2]
    pi = np.pi
    eq_part_1 = 1/(transformed * sigma * np.sqrt(2 * pi))
    eq_part_2 = np.exp(-((np.log(transformed)-mu)**2/(2*(sigma**2))))
    return range_factor * eq_part_1 * eq_part_2


def evaluate_function(func: str, minimum: int, maximum: int, par: List[float]) -> np.ndarray:
    chromosome_numbers = np.arange(minimum, maximum+1)
    if func == 'CONST':
        return Const(par, chromosome_numbers)
    elif func == "LINEAR":
        return Linear(par, chromosome_numbers)
    elif func == "LINEAR_BD":
        return Linear_BD(par, chromosome_numbers)
    elif func == "LOGNORMAL":
        return Log_normal(par, chromosome_numbers)
    elif func == "IGNORE":
        return None
    else:
        raise Exception("Not used function in simulation")


def get_functions(res_content: str) -> List[Tuple[str, str]]:
    section = re.search(r"Assigned functions for each rate parameter:(.*?)Shared parameters", res_content, re.DOTALL).group(1)
    p = re.compile("([\S]+):\s+([A-Z_]+)")
    transition_types_and_functions = p.findall(section)
    return transition_types_and_functions


def get_true_parameters(transition_type: str, content: str) -> Dict[int, List[float]]:
    p = re.compile(f"_{transition_type}_([\d]+)[\s]+=[\s]+[\d]+;([\S]+)")
    all_params = p.findall(content)
    dict_states_rates = {}
    for state, params in all_params:
        splitted_params = params.split(",")
        params_float = [float(i) for i in splitted_params]
        dict_states_rates[int(state)-1] = params_float
    return dict_states_rates


def get_parameters_for_transition_type(transition_type: str, res_content: str) -> Dict[int, List[float]]:

    p = re.compile(f"Chromosome\.{transition_type}([\d]+)_([\d]+)[\s]+value[\s]+is[\s]+([\S]+)")
    all_params = p.findall(res_content)
    all_params.sort(key=lambda x: int(x[0]))
    dict_states_rate_params = {}
    for index, state, value in all_params:
        if int(state)-1 in dict_states_rate_params:
            dict_states_rate_params[int(state)-1].append(float(value))
        else:
            dict_states_rate_params[int(state) - 1] = [float(value)]
    return dict_states_rate_params


def get_func(transition_types_with_func: List[Tuple[str, str]], transition_type: str) -> str:
    for rate, func in transition_types_with_func:
        if rate == transition_type:
            return func
    return None


def get_rate_difference(res_file: str, dict_transition_types_result_diff: Dict[str, List[float]], unite_polyploidy: int,
                        tree_true_scaling_factor: float, count_sim_file: str, trim_chromosome_number_range: int) -> None:
    file = open(res_file, 'r')
    content = file.read()
    file.close()
    min_chromosome_num, max_chromosome_num = get_min_max_counts_file(count_sim_file)
    scaling_factor = get_tree_scaling_factor(content)
    transition_types_with_func = get_functions(content)
    for transition_type, func in transition_types_with_func:
        max_chromosome_number = max_chromosome_num
        if func == "IGNORE":
            continue
        if unite_polyploidy and transition_type == "demi":
            continue
        dict_states_params = get_parameters_for_transition_type(transition_type, content)
        if trim_chromosome_number_range:
            if transition_type == "dupl":
                max_chromosome_number = math.floor(max_chromosome_num/2)
            elif transition_type == "demi":
                max_chromosome_number = math.ceil(max_chromosome_num/1.5)
            elif transition_type == "gain":
                max_chromosome_number = max_chromosome_num - 1
            else:
                max_chromosome_number = max_chromosome_num
        values_state_0 = evaluate_function(func, min_chromosome_num, max_chromosome_number, dict_states_params[0])
        values_state_1 = evaluate_function(func, min_chromosome_num, max_chromosome_number, dict_states_params[1])
        if unite_polyploidy and transition_type == "dupl":
            dict_states_params = get_parameters_for_transition_type("demi", content)
            demi_func = get_func(transition_types_with_func, "demi")
            values_state_0 += evaluate_function(demi_func, min_chromosome_num, max_chromosome_num, dict_states_params[0])
            values_state_1 += evaluate_function(demi_func, min_chromosome_num, max_chromosome_num, dict_states_params[1])
        difference = np.mean(values_state_1 - values_state_0) * (tree_true_scaling_factor/scaling_factor)
        if unite_polyploidy and transition_type == "dupl":
            dict_transition_types_result_diff["polyploidy"].append(difference)
        else:
            dict_transition_types_result_diff[transition_type].append(difference)


def get_func_from_param_file(transition_type: str, content: str):
    p = re.compile(f"_{transition_type}Func[\s]+=[\s]+([\S]+)")
    func = p.findall(content)[0]
    return func


def get_min_max_counts_file(counts_file_path: str) -> Tuple[int,int]:
    file = open(counts_file_path, 'r')
    content = file.read()
    file.close()
    p = re.compile(">[\S]+[\s]+([\d]+)", re.MULTILINE)
    chromosome_numbers_str = p.findall(content)
    chromosome_counts = [int(i) for i in chromosome_numbers_str]
    return min(chromosome_counts), max(chromosome_counts)


def update_true_params(sim_param_file: str, dict_rates_and_differences: Dict[str, List[float]], unite_polyploidy: int, counts_file_path: str, trim_range_for_poly: int) -> float:
    file = open(sim_param_file, 'r')
    content = file.read()
    dict_rate_params_func = {"gain":"gain", "loss":"loss", "dupl": "dupl", "demiPloidyR": "demiDupl"}
    file.close()
    pattern_tree_factor = re.compile("_branchMul[\s]+=[\s]+([\S]+)")
    tree_factor = float(pattern_tree_factor.findall(content)[0])
    min_chr, max_chr = get_min_max_counts_file(counts_file_path)
    for transition_type in dict_rates_and_differences:
        if transition_type == "sim":
            continue
        if transition_type == "demi":
            transition_rate_type = "demiPloidyR"
        elif transition_type == "polyploidy":
            transition_rate_type = "dupl"
        else:
            transition_rate_type = transition_type
        dict_params = get_true_parameters(transition_rate_type, content)
        func = get_func_from_param_file(dict_rate_params_func[transition_rate_type], content)
        values_state_0 = evaluate_function(func, min_chr, max_chr, dict_params[0])
        values_state_1 = evaluate_function(func, min_chr, max_chr, dict_params[1])
        if transition_rate_type == "dupl" and unite_polyploidy:
            maximum_chr_num = max_chr
            func = get_func_from_param_file(dict_rate_params_func["demiPloidyR"], content)
            dict_params = get_true_parameters("demiPloidyR", content)
            if trim_range_for_poly:
                if transition_rate_type == "dupl":
                    maximum_chr_num = math.floor(max_chr/2)
                elif transition_rate_type == "demi":
                    maximum_chr_num = math.ceil(max_chr/1.5)
                elif transition_rate_type == "gain":
                    maximum_chr_num = max_chr-1
                else:
                    maximum_chr_num = max_chr
            values_state_0 += evaluate_function(func, min_chr, maximum_chr_num, dict_params[0])
            values_state_1 += evaluate_function(func, min_chr, maximum_chr_num, dict_params[1])
        difference = np.mean(values_state_1 - values_state_0)
        if unite_polyploidy and transition_type == "dupl":
            dict_rates_and_differences["polyploidy"].append(difference)
        else:
            dict_rates_and_differences[transition_type].append(difference)
    return tree_factor





def assess_accuracy(simulation_dir: str, successful_simulations_path: str, threshold: float, output_file: str,
                    unite_polyploidy: int, sim_param_file: str, counts_file: str, trim_range_for_poly: int) -> None:
    df = pd.read_csv(successful_simulations_path, index_col=0)
    if unite_polyploidy:
        dict_rates_and_differences = {"sim": [], "gain": [], "loss": [], "polyploidy": []}

    else:
        dict_rates_and_differences = {"sim": [], "gain": [], "loss": [], "demi": [], "dupl": []}
    dict_rates_and_differences["sim"].append(-1)
    true_scaling_factor = update_true_params(sim_param_file, dict_rates_and_differences, unite_polyploidy, counts_file, trim_range_for_poly)
    if threshold is None:
        successful_simulations = df["sim"].tolist()
    else:
        successful_simulations = df[df['2delta_logLik'] > threshold]["sim"].tolist()
    for i in successful_simulations:
        chromevol_res_path = os.path.join(simulation_dir, f"{i}", "H1", "chromEvol.res")
        count_sim_file = os.path.join(simulation_dir, f"{i}", "counts.fasta")
        dict_rates_and_differences["sim"].append(i)
        get_rate_difference(chromevol_res_path, dict_rates_and_differences, unite_polyploidy, true_scaling_factor, count_sim_file, trim_range_for_poly)
    dataframe = pd.DataFrame(dict_rates_and_differences)
    dataframe.to_csv(output_file)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="run homogeneous analyses")
    parser.add_argument("--simulation_dir", "-s", help="directory of simulations")
    parser.add_argument("--df_simulations", "-d", help="path to a dataframe with successful simulations")
    parser.add_argument("--threshold", "-t", type=float, help="threshold", default=None)
    parser.add_argument("--output", "-o", help="output file")
    parser.add_argument("--unite_polyploidy", "-p", type=int, help="unite polyploidy rates")
    parser.add_argument("--sim_param_file", "-sim", help="simulation parameter file")
    parser.add_argument("--counts_file", "-c", help="counts file")
    parser.add_argument("--trim_range_for_poly", "-tr", type=int, default=0, help="trim chromosome number range for the truly relevant range")
    args = parser.parse_args()
    simulation_dir = args.simulation_dir
    df_simulations_path = args.df_simulations
    threshold = args.threshold
    output_file = args.output
    unite_polyploidy = args.unite_polyploidy
    sim_param_file = args.sim_param_file
    counts_file = args.counts_file
    trim_range_for_poly = args.trim_range_for_poly
    assess_accuracy(simulation_dir, df_simulations_path, threshold, output_file, unite_polyploidy, sim_param_file, counts_file, trim_range_for_poly)








