import os
import re
import shutil
import random
import argparse
from typing import Dict, Set


def test_simulations_proportions_states(sim_path: str, num_of_simulations: int) -> None:
    total_prop_dic = {}
    count_failed = 0
    total_existing_sims = 0
    for i in range(num_of_simulations):
        observed_states = set()
        states_occurrences = {}
        sim_dir = os.path.join(sim_path, f"{i}")
        if not os.path.exists(sim_dir):
            continue
        data_path = os.path.join(sim_dir, "trait_sim.fasta")
        fill_dict_of_state_occurrences(data_path, states_occurrences, observed_states)
        number_of_taxa = sum(states_occurrences[k] for k in states_occurrences)
        total_existing_sims += 1

        if (len(observed_states) < 2) or ((states_occurrences[1]/number_of_taxa) > 0.9):
            print(f"Failed sim_{i}")
            count_failed += 1
            shutil.rmtree(sim_dir)
        for state in states_occurrences:
            prop = states_occurrences[state] / number_of_taxa
            if state in total_prop_dic:
                total_prop_dic[state] += prop
            else:
                total_prop_dic[state] = prop
    for state in total_prop_dic:
        total_prop_dic[state] /= total_existing_sims
        print(f'{state} : {total_prop_dic[state]}')
    print(f"number of failed simulations is: {count_failed}\n")
    print(f"number of successful {total_existing_sims}")
    return


def test_simulations_transitions(sim_evo_path: str) -> None:
    pattern_per_rate = re.compile("from state:[\s]+([\d]+)[\s]+t[\s]+=[\s]+[\S]+[\s]+to state[\s]+=[\s]+([\d]+)")
    file = open(sim_evo_path, 'r')
    content = file.read()
    file.close()
    transitions_per_rate = pattern_per_rate.findall(content)
    dict_transitions = {}
    for from_state, to_state in transitions_per_rate:
        transition = f"{from_state}->{to_state}"
        if not (transition in dict_transitions):
            dict_transitions[transition] = 1
        else:
            dict_transitions[transition] += 1
    for transition in dict_transitions:
        print(f"{transition} = {dict_transitions[transition]}\n")


def fill_dict_of_state_occurrences(simulated_trait_path: str, dict_states_occurrences: Dict[int,int],
                                   observed_states: Set[int]) -> None:
    pattern = re.compile("([\S]+)[\s]+([\d]+)")
    file = open(simulated_trait_path, 'r')
    content = file.read()
    file.close()
    seq_state = pattern.findall(content)
    for seq, str_state in seq_state:
        state = int(str_state)
        observed_states.add(state)
        if state in dict_states_occurrences:
            dict_states_occurrences[state] += 1
        else:
            dict_states_occurrences[state] = 1


def leave_required(simulations_path: str, required: int) -> None:
    all_sim_dirs = os.listdir(simulations_path)
    chosen_simulations = random.sample(all_sim_dirs, required)
    set_of_dirs_to_remove = set(all_sim_dirs) - set(chosen_simulations)
    for i in set_of_dirs_to_remove:
        sim_dir = os.path.join(simulations_path, i)
        shutil.rmtree(sim_dir)
    chosen_simulations_int = [int(i) for i in chosen_simulations]
    chosen_simulations_int.sort()
    for i in range(required):
        if chosen_simulations_int[i] != i:
            current_dir_name = os.path.join(simulations_path, f"{chosen_simulations_int[i]}")
            new_dir_name = os.path.join(simulations_path, f"{i}")
            os.rename(current_dir_name, new_dir_name)
    total_prop_dic = {}
    for i in range(required):
        dict_of_sim_states_occurrences = {}
        observed_states = set()
        sim_dir = os.path.join(simulations_path, f"{i}")
        data_path = os.path.join(sim_dir, "trait_sim.fasta")
        fill_dict_of_state_occurrences(data_path, dict_of_sim_states_occurrences, observed_states)
        number_of_taxa = sum(dict_of_sim_states_occurrences[k] for k in dict_of_sim_states_occurrences)
        for state in dict_of_sim_states_occurrences:
            prop = dict_of_sim_states_occurrences[state] / number_of_taxa
            if state in total_prop_dic:
                total_prop_dic[state] += prop
            else:
                total_prop_dic[state] = prop
    for state in total_prop_dic:
        total_prop_dic[state] /= required
        print(f'{state} : {total_prop_dic[state]}')


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="run homogeneous analyses")
    parser.add_argument("--simulation_dir", "-s", help="simulation directory")
    parser.add_argument("--num_of_total", "-t", type=int, help="total number of simulations")
    parser.add_argument("--number_of_required", "-r", type=int, help = "number of requried")
    args = parser.parse_args()
    simulation_dir = args.simulation_dir
    num_of_total = args.num_of_total
    number_of_required = args.number_of_required

    test_simulations_proportions_states(simulation_dir, num_of_total)
    leave_required(simulation_dir, number_of_required)






